<div class="container">
    <h1 class="mt-4"></h1>
    <p></p>
    <img src="<?= BASEURL; ?>/img/sayur.jpeg "alt="sayur" width="200"  class="rounded-circle">

</div>

<div class="container">
<div class="jumbotron mt-4">
  <h1 class="display-4">Welcome To World Of Vegetables !</h1>
  <p class="lead">Vegetable Online Shop <?= $data['nama']; ?></p>
  <hr class="my-4">
  <p>Selling Various Kinds Of Vegetables & Fruits</p>
  <a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
</div>


</div>

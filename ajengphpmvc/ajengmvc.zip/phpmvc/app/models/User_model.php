<?php

class User_model {
    private $nama = '';

    public function getUser()
    {
        return $this->nama;
    }
}
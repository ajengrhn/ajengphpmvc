<?php

class produk_model
{
    private $table = 'produk';
    private $db;

    public function __construct()
    {
        $this->db = new Database;
    }

    public function getAllProduk()
    {
        $this->db->query('SELECT * FROM ' . $this->table);
        return $this->db->resultset();
    }

    public function getProdukByid($id)
    {
        $this->db->query("SELECT * FROM `produk` WHERE id = :id");
        $this->db->bind("id", $id);
        return $this->db->single();
    }

    public function tambahDataProduk($data)
    {
        $query = "INSERT INTO produk 
                   VALUES
                  ('' , :nama_produk, :kode_produk, :harga, :jenis_produk)";

        $this->db->query($query);
        $this->db->bind('nama_produk', $data['nama_produk']);
        $this->db->bind('kode_produk', $data['kode_produk']);
        $this->db->bind('harga', $data['harga']);
        $this->db->bind('jenis_produk', $data['jenis_produk']);

        $this->db->execute();

        return $this->db->rowcount();
    }

    public function hapusDataProduk($id)
    {
        $query = "DELETE FROM produk WHERE id = :id";
        $this->db->query($query);
        $this->db->bind('id', $id);

        $this->db->execute();

        return $this->db->rowCount();
    }
    public function ubahDataProduk($data)
    {
        $query = "UPDATE produk SET
                  nama_produk = :nama_produk, 
                  kode_produk = :kode_produk,
                  harga = :harga,
                  jenis_produk = :jenis_produk 
                  WHERE id = :id";
    
        $this->db->query($query);
        $this->db->bind('nama_produk', $data['nama_produk']);
        $this->db->bind('kode_produk', $data['kode_produk']);
        $this->db->bind('harga', $data['harga']);
        $this->db->bind('jenis_produk', $data['jenis_produk']);
        $this->db->bind('id', $data['id']);
    
        $this->db->execute();
    
        return $this->db->rowcount();
    }
    public function cariProduk()
    {
       $keyword = $_POST['keyword'];
       $query = "SELECT * FROM produk WHERE nama LIKE :keyword";
       $this->db->query($query);
       $this->db->bind('keyword', "%$keyword%");
       return $this->db->resultset();
  
    }
}